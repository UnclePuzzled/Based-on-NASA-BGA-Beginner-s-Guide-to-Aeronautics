# Change Log - Nozzle.java Refactoring
## 2025-05-17 by UnclePuzzled

### Initial Setup:
- Forked and adapted NASA Glenn Research Center's `Stage.java` applet (Public Domain).
- Compiled legacy applet code into a standalone desktop application.
- Packaged with embedded JRE and executable (`.exe`) launcher using Launch4j.

### Changed:
- Replaced deprecated `java.applet.Applet` with `javax.swing.JFrame` and `JPanel`.
- Converted `Panel` to `JPanel`, `Canvas` to `JPanel`, `TextField` to `JTextField`, `Label` to `JLabel`, `Choice` to `JComboBox`, `Button` to `JButton`, and `Scrollbar` to `JSlider`.
- Rewrote event handling: replaced `action(Event, Object)` and `handleEvent(Event)` with modern `ActionListener`, `ChangeListener`, `MouseListener`, and `MouseMotionListener`.
- Replaced offscreen buffering (`createImage`, `offscreenImg`) with direct `paintComponent()` rendering in Swing.
- Enabled standalone execution via `main()` method and `SwingUtilities.invokeLater()`.
- Replaced custom `filter3` and `filter0` methods with `DecimalFormat` for consistent number formatting.
- Improved graphics rendering using `Graphics2D` with anti-aliasing for smoother visuals.
- Fixed bug in area output for convergent-divergent nozzles by setting `athrust` to `aexit` (previously used `ath` incorrectly).
- Changed default nozzle type to "Rocket" as per requirements (`plntyp = 1` in `setDefaults()`).
- Updated layout slightly by adjusting panel sizes for better visibility in modern resolutions.
- Preserved core functionality, including propellant options, gamma calculation, and nozzle geometry.

### Added:
- `JFrame` window for standalone execution.
- Thread-safe GUI initialization using `SwingUtilities.invokeLater`.
- `DecimalFormat` for formatting output numbers (e.g., `0.000` for three decimals, `0` for integers).
- Anti-aliasing in graphics rendering for improved visual quality.

### Removed:
- Applet-specific methods (`init()`, `insets()`).
- Commented-out diagnostic fields (`diag3`, `diag4`) in `T6` panel.
- Graphics input panel (as per requirements, removed direct manipulation via sliders in `Viewer`).
- Unnecessary offscreen image buffering.

### Notes:
- The "Reset" button functionality was already present and preserved.
- Propellant options (Air, H2-O2, JP 10-O2) and gamma as a function of temperature were already implemented and retained.
- Units are included in output labels (e.g., "psi", "sq ft") as per requirements.
- The `getAir` method was already renamed to `getMfr` in the original code.