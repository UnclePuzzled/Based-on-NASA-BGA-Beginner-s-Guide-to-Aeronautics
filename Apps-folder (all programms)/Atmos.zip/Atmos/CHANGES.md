# Change Log - Atmos.java Refactoring
## 2025-05-16 by UnclePuzzled


### Initial Setup:
- Forked and adapted NASA Glenn Research Center's `Stage.java` applet (Public Domain).
- Compiled legacy applet code into a standalone desktop application.
- Packaged with embedded JRE and executable (`.exe`) launcher using Launch4j.

### Changed:
- Replaced deprecated `java.applet.Applet` with `javax.swing.JFrame` and `JPanel`.
- Converted `Panel` to `JPanel`, `Canvas` to `JPanel`, `TextField` to `JTextField`, `Label` to `JLabel`, `Choice` to `JComboBox`, and `Checkbox` to `JRadioButton`.
- Removed `getImage(getCodeBase())` and commented-out image loading references (`plnimg`, `mplnimg`).
- Rewrote graphics rendering using `paintComponent()` override with `Graphics2D`.
- Replaced old event handling (`action(Event, Object)`) with modern `ActionListener` and `MouseListener`/`MouseMotionListener`.
- Enabled standalone execution via `main()` method and `SwingUtilities.invokeLater()`.
- Replaced custom `filter0`, `filter3`, `filter5` methods with `DecimalFormat` for number formatting.
- Removed offscreen buffering (`createImage`, `offscreenImg`, `offImg2`) as unnecessary in Swing.
- Removed erroneous `BottleneckExecutorService` reference in `handleText()` method and simplified logic for clamping altitude input.

### Added:
- `JFrame` window with dynamic controls and visualization area.
- Thread-safe GUI initialization using `SwingUtilities.invokeLater`.
- `DecimalFormat` for consistent number formatting in outputs.

### Removed:
- All applet-specific methods (`init()`, `insets()`, etc.) and browser-based execution references.
- Commented-out aircraft image loading code for security compliance.