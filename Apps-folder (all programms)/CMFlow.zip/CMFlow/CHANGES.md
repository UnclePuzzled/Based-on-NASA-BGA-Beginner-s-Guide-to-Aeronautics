# Change Log - CMFlow.java Refactoring
## 2025-05-16 by UnclePuzzled

### Initial Setup:
- Forked and adapted NASA Glenn Research Center's `Stage.java` applet (Public Domain).
- Compiled legacy applet code into a standalone desktop application.
- Packaged with embedded JRE and executable (`.exe`) launcher using Launch4j.

### Changed:
- Replaced deprecated `java.applet.Applet` with `javax.swing.JFrame` and `JPanel`.
- Converted `Panel` to `JPanel`, `TextField` to `JTextField`, `Label` to `JLabel`, `Choice` to `JComboBox`, and `Button` to `JButton`.
- Rewrote event handling: replaced `action(Event, Object)` with modern `ActionListener` for buttons, combo boxes, and text fields.
- Enabled standalone execution via `main()` method and `SwingUtilities.invokeLater()`.
- Replaced custom `filter3` and `filter5` methods with `DecimalFormat` for consistent number formatting.
- Removed applet-specific methods (`init()`, `insets()`).
- Simplified `handleBut()` method by removing unnecessary `float` casting and using `double` directly for input validation.
- Preserved original layout and functionality with minimal structural changes.

### Added:
- `JFrame` window for standalone execution.
- Thread-safe GUI initialization using `SwingUtilities.invokeLater`.
- `DecimalFormat` for formatting output numbers to three decimal places.

### Removed:
- Applet-specific code and browser-based execution references.
- Unused `filter5` method (not used in the program).